package com.example.snowcapui.network;

import java.io.*;
import java.net.*;
import org.json.JSONObject;

public class ApiClient {

    private static final String SERVER_URL = "http://rosmaster_ip:5000"; // Replace with actual IP

    public static String getStatus() throws IOException {
        URL url = new URL(SERVER_URL + "/get_status");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");

        BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        StringBuilder response = new StringBuilder();
        String line;

        while ((line = reader.readLine()) != null) {
            response.append(line);
        }
        reader.close();

        // Extract the salt dispensing rate from JSON
        try {
            JSONObject jsonResponse = new JSONObject(response.toString());
            return jsonResponse.getString("salt_rate"); // Ensure your API returns "salt_rate"
        } catch (Exception e) {
            return "Invalid data format";
        }
    }
}
